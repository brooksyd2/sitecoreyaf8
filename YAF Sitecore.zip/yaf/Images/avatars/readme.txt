
*** AVATARS ***

Avatars must be put into subfolders of this directory. 
Otherwise they won't be recognized by yaf and displayed
to the user.

Example:
<yafroot>/images/avatars/myavatars